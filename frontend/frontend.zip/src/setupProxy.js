const { createProxyMiddleware } = require('http-proxy-middleware');
const { createProxyMiddleware: createProxy } = require('http-proxy-middleware');

module.exports = function(app) {
  // Proxy API requests to the backend
  app.use(
    '/api',
    createProxy({
      target: process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000',
      changeOrigin: true,
      secure: false,
      pathRewrite: {
        '^/api': '/api/v1', // Rewrite /api to /api/v1
      },
      onProxyReq: (proxyReq, req, res) => {
        // Add CORS headers
        proxyReq.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');
        proxyReq.setHeader('Access-Control-Allow-Credentials', 'true');
        proxyReq.setHeader('X-Forwarded-Proto', 'http');
      },
      onProxyRes: (proxyRes, req, res) => {
        proxyRes.headers['Access-Control-Allow-Origin'] = 'http://localhost:3000';
        proxyRes.headers['Access-Control-Allow-Credentials'] = 'true';
      },
      logLevel: 'debug',
      ws: true, // WebSocket support
      rejectUnauthorized: false, // Don't verify SSL certificates
    })
  );

  // Health check endpoint
  app.use(
    '/health',
    createProxy({
      target: process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000',
      changeOrigin: true,
      secure: false,
      pathRewrite: {
        '^/health': '/api/v1/health',
      },
    })
  );
};
