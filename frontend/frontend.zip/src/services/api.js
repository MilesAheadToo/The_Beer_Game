import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000/api/v1';

// Set up axios instance with default config
const api = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: false, // Important for cookies/sessions if using them
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

// Add request interceptor to include auth token
api.interceptors.request.use(
  (config) => {
    // Skip auth header if explicitly disabled
    if (config.skipAuth) {
      return config;
    }
    
    const token = localStorage.getItem('access_token');
    // Normalize token type to 'Bearer' with capital B
    const tokenType = (localStorage.getItem('token_type') || 'Bearer').replace(/^bearer$/i, 'Bearer');
    
    if (token) {
      // Ensure we don't duplicate the token type and trim any whitespace
      const cleanToken = token.trim().replace(new RegExp(`^${tokenType}\\s+`, 'i'), '');
      config.headers.Authorization = `${tokenType} ${cleanToken}`.trim();
      
      // For debugging
      console.log('Setting auth header:', {
        hasToken: !!token,
        tokenType,
        header: config.headers.Authorization.substring(0, 30) + '...'
      });
    } else {
      console.log('No auth token found for request');
    }
    
    return config;
  },
  (error) => {
    console.error('Request interceptor error:', error);
    return Promise.reject(error);
  }
);

// Add response interceptor to handle common errors
api.interceptors.response.use(
  (response) => {
    // Log successful responses for debugging
    if (response.config.url.includes('/auth/')) {
      console.log('Auth API response:', {
        url: response.config.url,
        status: response.status,
        data: response.data ? '...' : 'no data'
      });
    }
    return response;
  },
  (error) => {
    const originalRequest = error.config;
    
    // Don't handle errors for login requests - let the Login component handle them
    if (originalRequest?.url && /\/auth\/login\b/.test(originalRequest.url)) {
      return Promise.reject(error);
    }
    
    // Skip auth error handling for requests with skipAuth flag
    if (originalRequest?.skipAuth) {
      return Promise.reject(error);
    }
    
    // Handle 401 Unauthorized
    if (error.response?.status === 401) {
      console.log('Authentication required');
      
      // Clear any invalid tokens
      localStorage.removeItem('access_token');
      localStorage.removeItem('token_type');
      
      // Only redirect if we're not already on the login page
      if (!window.location.pathname.includes('/login')) {
        const redirect = window.location.pathname + window.location.search;
        window.location.href = `/login?redirect=${encodeURIComponent(redirect)}`;
      }
      
      return Promise.reject(new Error('Session expired. Please log in again.'));
    }
    
    // Log other errors
    if (error.response) {
      // The request was made and the server responded with a status code
      console.error('API Error Response:', {
        status: error.response.status,
        statusText: error.response.statusText,
        url: originalRequest?.url,
        method: originalRequest?.method,
        data: error.response.data
      });
    } else if (error.request) {
      // The request was made but no response was received
      console.error('API Request Error:', {
        message: error.message,
        url: originalRequest?.url,
        method: originalRequest?.method
      });
    } else {
      // Something happened in setting up the request
      console.error('API Setup Error:', error.message);
    }
    
    return Promise.reject(error);
  }
);

// Mixed Game API
export const mixedGameApi = {
  // Create a new mixed game
  createGame: async (gameData) => {
    try {
      const response = await api.post('/mixed-games/', gameData);
      return response.data;
    } catch (error) {
      console.error('Error creating mixed game:', error);
      throw error;
    }
  },

  // Get all mixed games
  getGames: async (status) => {
    try {
      const params = status ? { status } : {};
      const response = await api.get('/mixed-games/', { params });
      return response.data;
    } catch (error) {
      console.error('Error fetching mixed games:', error);
      throw error;
    }
  },

  // Get a single mixed game by ID
  getGame: async (gameId) => {
    try {
      const response = await api.get(`/mixed-games/${gameId}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching mixed game ${gameId}:`, error);
      throw error;
    }
  },

  // Update a mixed game
  updateGame: async (gameId, gameData) => {
    try {
      const response = await api.put(`/mixed-games/${gameId}`, gameData);
      return response.data;
    } catch (error) {
      console.error(`Error updating mixed game ${gameId}:`, error);
      throw error;
    }
  },

  // Start a mixed game
  startGame: async (gameId) => {
    try {
      const response = await api.post(`/mixed-games/${gameId}/start`);
      return response.data;
    } catch (error) {
      console.error(`Error starting mixed game ${gameId}:`, error);
      throw error;
    }
  },

  // Stop a mixed game
  stopGame: async (gameId) => {
    try {
      const response = await api.post(`/mixed-games/${gameId}/stop`);
      return response.data;
    } catch (error) {
      console.error(`Error stopping mixed game ${gameId}:`, error);
      throw error;
    }
  },

  // Advance to next round
  nextRound: async (gameId) => {
    try {
      const response = await api.post(`/mixed-games/${gameId}/next-round`);
      return response.data;
    } catch (error) {
      console.error(`Error advancing to next round in game ${gameId}:`, error);
      throw error;
    }
  },

  // Get game state
  getGameState: async (gameId) => {
    try {
      const response = await api.get(`/mixed-games/${gameId}/state`);
      return response.data;
    } catch (error) {
      console.error(`Error getting state for game ${gameId}:`, error);
      throw error;
    }
  },

  // Get game results
  getGameResults: async (gameId) => {
    try {
      const response = await api.get(`/mixed-games/${gameId}/results`);
      return response.data;
    } catch (error) {
      console.error(`Error getting results for game ${gameId}:`, error);
      throw error;
    }
  }
};

// Original Game API
export const gameApi = {
  // Get all games
  getGames: async () => {
    try {
      const response = await api.get('/mixed-games/');
      return response.data;
    } catch (error) {
      console.error('Error fetching games:', error);
      throw error;
    }
  },

  // Get a single game by ID
  getGame: async (gameId) => {
    try {
      const response = await api.get(`/games/${gameId}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching game ${gameId}:`, error);
      throw error;
    }
  },

  // Create a new game
  createGame: async (gameData) => {
    try {
      const response = await api.post('/games/', gameData);
      return response.data;
    } catch (error) {
      console.error('Error creating game:', error);
      throw error;
    }
  },

  // Update a game
  updateGame: async (gameId, gameData) => {
    try {
      const response = await api.put(`/games/${gameId}`, gameData);
      return response.data;
    } catch (error) {
      console.error(`Error updating game ${gameId}:`, error);
      throw error;
    }
  },

  // Delete a game
  deleteGame: async (gameId) => {
    try {
      await api.delete(`/games/${gameId}`);
    } catch (error) {
      console.error(`Error deleting game ${gameId}:`, error);
      throw error;
    }
  },

  // Start a game
  startGame: async (gameId) => {
    try {
      const response = await api.post(`/games/${gameId}/start`);
      return response.data;
    } catch (error) {
      console.error(`Error starting game ${gameId}:`, error);
      throw error;
    }
  },
};

export default api;
