import axios from "axios";
import { toast } from "react-toastify";

// Resolve API base URL. Supports Vite (VITE_API_BASE_URL) and CRA (REACT_APP_API_BASE_URL).
const API_BASE_URL =
  (typeof import.meta !== "undefined" && import.meta.env?.VITE_API_BASE_URL) ||
  process.env.REACT_APP_API_BASE_URL ||
  "http://localhost:8000/api/v1";

// Create axios instance with default config
const http = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true, // Required for cookies
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
  timeout: 30000, // 30 seconds
});

/**
 * Read a cookie value by name
 * @param {string} name - Cookie name
 * @returns {string|null} Cookie value or null if not found
 */
function getCookie(name) {
  if (typeof document === 'undefined') return null; // SSR guard
  
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
  return null;
}

// Request interceptor for auth token and CSRF
http.interceptors.request.use(
  (config) => {
    // Skip for external URLs
    if (!config.url.startsWith(API_BASE_URL)) return config;

    // Add CSRF token for non-GET requests
    if (config.method !== 'get' && config.method !== 'head') {
      const csrfToken = getCookie('csrftoken') || getCookie('XSRF-TOKEN');
      if (csrfToken) {
        config.headers['X-CSRF-Token'] = csrfToken;
      }
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
http.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    // Handle 401 Unauthorized
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        // Try to refresh the token
        await http.post('/auth/refresh');
        // Retry the original request
        return http(originalRequest);
      } catch (refreshError) {
        // Refresh failed, redirect to login
        if (typeof window !== 'undefined') {
          window.location.href = '/login';
        }
        return Promise.reject(refreshError);
      }
    }
    
    // Handle CSRF token errors
    if (error.response?.status === 403 && error.response.data?.detail === 'CSRF token validation failed') {
      // Try to get a new CSRF token
      try {
        await http.get('/auth/csrf-token');
        // Retry the original request
        return http(originalRequest);
      } catch (csrfError) {
        console.error('CSRF token refresh failed:', csrfError);
      }
    }
    
    // Show error toast for server errors
    if (error.response?.status >= 500) {
      toast.error('A server error occurred. Please try again later.');
    }
    
    return Promise.reject(error);
  }
);

/**
 * Auth API service
 */
export const authApi = {
  /**
   * Login with username/email and password
   * @param {Object} credentials - Login credentials
   * @param {string} credentials.username - Username or email
   * @param {string} credentials.password - Password
   * @param {boolean} [rememberMe=false] - Whether to remember the user
   * @returns {Promise<Object>} User data
   */
  async login({ username, password, rememberMe = false }) {
    const formData = new URLSearchParams();
    formData.append('username', username);
    formData.append('password', password);
    if (rememberMe) formData.append('scope', 'remember_me');
    
    const response = await http.post('/auth/login', formData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });
    
    return response.data;
  },
  
  /**
   * Get current user data
   * @returns {Promise<Object>} User data
   */
  async me() {
    const response = await http.get('/auth/me');
    return response.data;
  },
  
  /**
   * Logout the current user
   * @returns {Promise<void>}
   */
  async logout() {
    try {
      await http.post('/auth/logout');
    } finally {
      // Clear all auth-related data
      if (typeof window !== 'undefined') {
        // Clear any stored tokens
        document.cookie = 'access_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        document.cookie = 'refresh_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        
        // Redirect to login
        window.location.href = '/login';
      }
    }
  },
  
  /**
   * Request a password reset email
   * @param {string} email - User's email address
   * @returns {Promise<void>}
   */
  async requestPasswordReset(email) {
    await http.post('/auth/forgot-password', { email });
  },
  
  /**
   * Reset password with a token
   * @param {string} token - Password reset token
   * @param {string} newPassword - New password
   * @returns {Promise<void>}
   */
  async resetPassword(token, newPassword) {
    await http.post('/auth/reset-password', { token, new_password: newPassword });
  },
};

/**
 * Game API service
 */
export const gameApi = {
  // Game management
  createGame: (payload) => http.post("/games", payload),
  listGames: (params) => http.get("/games", { params }),
  getGame: (id) => http.get(`/games/${id}`),
  updateGame: (id, data) => http.patch(`/games/${id}`, data),
  deleteGame: (id) => http.delete(`/games/${id}`),
  
  // Game actions
  startGame: (id) => http.post(`/games/${id}/start`),
  joinGame: (id, role) => http.post(`/games/${id}/join`, { role }),
  leaveGame: (id) => http.post(`/games/${id}/leave`),
  
  // Gameplay actions
  submitOrder: (gameId, order) => http.post(`/games/${gameId}/orders`, order),
  getOrders: (gameId) => http.get(`/games/${gameId}/orders`),
  getHistory: (gameId) => http.get(`/games/${gameId}/history`),
  
  // Chat
  getChatMessages: (gameId) => http.get(`/games/${gameId}/chat`),
  sendChatMessage: (gameId, message) => 
    http.post(`/games/${gameId}/chat`, { message }),
};

/**
 * User API service
 */
export const userApi = {
  getProfile: () => http.get("/users/me"),
  updateProfile: (data) => http.patch("/users/me", data),
  changePassword: (currentPassword, newPassword) => 
    http.post("/users/me/change-password", { currentPassword, newPassword }),
  
  // MFA setup
  setupMFA: () => http.post("/users/me/mfa/setup"),
  verifyMFA: (code) => http.post("/users/me/mfa/verify", { code }),
  disableMFA: () => http.post("/users/me/mfa/disable"),
  getRecoveryCodes: () => http.get("/users/me/mfa/recovery-codes"),
  generateRecoveryCodes: () => http.post("/users/me/mfa/recovery-codes/generate"),
};

// For backward compatibility
export const mixedGameApi = gameApi;

// Export the configured http client as default
export default http;
