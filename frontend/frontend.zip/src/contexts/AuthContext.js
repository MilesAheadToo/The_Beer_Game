import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [isAuthenticated, setIsAuthenticated] = useState(() =>
    !!localStorage.getItem("access_token")
  );
  const [loading, setLoading] = useState(false);

  const login = ({ access_token, token_type = "Bearer" }) => {
    localStorage.setItem("access_token", access_token);
    localStorage.setItem("token_type", token_type.replace(/^bearer$/i, "Bearer"));
    setIsAuthenticated(true);                // <- critical to stop the loop
  };

  const logout = () => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("token_type");
    setIsAuthenticated(false);
  };

  // Keep state in sync if another tab logs in/out
  useEffect(() => {
    const onStorage = () => setIsAuthenticated(!!localStorage.getItem("access_token"));
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  return (
    <AuthContext.Provider value={{ isAuthenticated, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export default AuthContext;
