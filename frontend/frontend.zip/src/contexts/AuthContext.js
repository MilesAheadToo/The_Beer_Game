import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { authApi } from '../services/api';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

// Create auth context with default values
const AuthContext = createContext({
  user: null,
  loading: true,
  isAuthenticated: false,
  login: async () => {},
  logout: async () => {},
  refreshSession: async () => {},
  hasRole: () => false,
  hasAnyRole: () => false,
});

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Refresh the current user session
  const refreshSession = useCallback(async () => {
    try {
      const userData = await authApi.me();
      setUser(userData);
      setError(null);
      return userData;
    } catch (err) {
      console.error('Session refresh failed:', err);
      setUser(null);
      const errorMessage = err.response?.data?.detail || 'Session expired. Please log in again.';
      setError(errorMessage);
      // Only redirect to login if not already there
      if (window.location.pathname !== '/login') {
        navigate('/login', { replace: true });
      }
      return null;
    }
  }, [navigate]);

  // Handle login
  const login = async ({ username, password, rememberMe = false }) => {
    try {
      setLoading(true);
      setError(null);
      await authApi.login({ username, password, rememberMe });
      const userData = await refreshSession();
      
      if (userData) {
        toast.success(`Welcome back, ${userData.username || userData.email}!`);
        return { success: true };
      }
      return { success: false, error: 'Login failed' };
    } catch (err) {
      console.error('Login error:', err);
      const errorMessage = err.response?.data?.detail || 'Login failed. Please check your credentials.';
      toast.error(errorMessage);
      setError(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  };

  // Handle logout
  const logout = async (options = {}) => {
    const { redirect = true, silent = false } = options;
    
    try {
      await authApi.logout();
      if (!silent) {
        toast.success('You have been logged out successfully');
      }
    } catch (err) {
      console.error('Logout error:', err);
      if (!silent) {
        toast.error('Failed to log out. Please try again.');
      }
    } finally {
      setUser(null);
      setLoading(false);
      
      if (redirect && window.location.pathname !== '/login') {
        navigate('/login', { replace: true });
      }
    }
  };

  // Check if user has a specific role
  const hasRole = (role) => {
    if (!user || !user.roles) return false;
    return user.roles.includes(role);
  };

  // Check if user has any of the specified roles
  const hasAnyRole = (roles) => {
    if (!user || !user.roles) return false;
    return roles.some(role => user.roles.includes(role));
  };

  // Check authentication status on mount and when user changes
  useEffect(() => {
    let isMounted = true;
    
    const checkAuth = async () => {
      try {
        if (isMounted) {
          const userData = await authApi.me();
          if (isMounted) {
            setUser(userData);
            setError(null);
          }
        }
      } catch (err) {
        if (isMounted) {
          setUser(null);
          const errorMessage = err.response?.data?.detail || 'Session expired. Please log in again.';
          setError(errorMessage);
          if (window.location.pathname !== '/login') {
            navigate('/login', { replace: true });
          }
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    // Only check if we're not already loading and don't have a user
    if (loading === false && !user) {
      checkAuth();
    }

    return () => {
      isMounted = false;
    };
  }, [navigate]); // Only include navigate in the dependency array

  const isAuthenticated = !!user;

  return (
    <AuthContext.Provider 
      value={{
        user,
        loading,
        error,
        isAuthenticated,
        login,
        logout,
        refreshSession,
        hasRole,
        hasAnyRole,
      }}
    >
      {!loading ? children : (
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      )}
    </AuthContext.Provider>
  );
}
