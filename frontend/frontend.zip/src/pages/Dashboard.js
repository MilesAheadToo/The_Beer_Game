import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Box, 
  Grid, 
  Typography, 
  Button, 
  CircularProgress,
  Paper,
  Container 
} from '@mui/material';
import { Add as AddIcon } from '@mui/icons-material';
import { toast } from 'react-toastify';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { mixedGameApi } from '../services/api';
import FilterBar from '../components/FilterBar';
import KPIStat from '../components/KPIStat';
import ChartCard from '../components/ChartCard';
import SkuTable from '../components/SkuTable';

// Sample data for the template-like dashboard
const demandSeries = [
  { name: 'W1', actual: 2100, forecast: 2200, target: 2000 },
  { name: 'W2', actual: 2250, forecast: 2300, target: 2050 },
  { name: 'W3', actual: 2150, forecast: 2350, target: 2100 },
  { name: 'W4', actual: 2300, forecast: 2400, target: 2100 },
  { name: 'W5', actual: 2400, forecast: 2380, target: 2150 },
  { name: 'W6', actual: 2350, forecast: 2450, target: 2150 },
  { name: 'W7', actual: 2420, forecast: 2500, target: 2200 },
  { name: 'W8', actual: 2380, forecast: 2480, target: 2200 },
  { name: 'W9', actual: 2450, forecast: 2550, target: 2250 },
  { name: 'W10', actual: 2480, forecast: 2580, target: 2250 },
  { name: 'W11', actual: 2460, forecast: 2600, target: 2300 },
  { name: 'W12', actual: 2520, forecast: 2650, target: 2300 },
];

const stockVsSafety = [
  { name: 'Widget A', stock: 1800, safety: 400 },
  { name: 'Widget B', stock: 900, safety: 300 },
  { name: 'Component C', stock: 7500, safety: 800 },
  { name: 'Assembly D', stock: 1200, safety: 350 },
  { name: 'Module E', stock: 320, safety: 100 },
  { name: 'Part F', stock: 6780, safety: 500 },
];

const stockVsForecast = [
  { name: 'Widget A', stock: 1800, forecast: 2200 },
  { name: 'Widget B', stock: 900, forecast: 1200 },
  { name: 'Component C', stock: 7500, forecast: 3900 },
  { name: 'Assembly D', stock: 1200, forecast: 1500 },
  { name: 'Module E', stock: 320, forecast: 500 },
  { name: 'Part F', stock: 6780, forecast: 5200 },
];

function useQuery() {
  const { search } = useLocation();
  return new URLSearchParams(search);
}

const Dashboard = () => {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [gameResult, setGameResult] = useState(null);
  const [loadingResult, setLoadingResult] = useState(false);
  const navigate = useNavigate();
  const query = useQuery();
  const gameId = query.get('gameId');

  // Fetch game results when gameId changes
  useEffect(() => {
    let alive = true;
    
    const fetchGameResults = async () => {
      if (!gameId) return;
      
      try {
        setLoadingResult(true);
        const data = await mixedGameApi.getGameResults(gameId);
        if (alive) {
          setGameResult(data);
        }
      } catch (error) {
        console.error('Failed to load game results', error);
        if (alive) {
          toast.error('Failed to load game results');
        }
      } finally {
        if (alive) setLoadingResult(false);
      }
    };
    
    fetchGameResults();
    
    return () => {
      alive = false;
    };
  }, [gameId]);

  useEffect(() => {
    const checkAuthAndFetchGames = async () => {
      try {
        setLoading(true);
        // First check if we're actually authenticated
        const token = localStorage.getItem('access_token');
        if (!token) {
          console.log('No access token found, redirecting to login');
          navigate('/login');
          return;
        }

        // Then fetch games
        const gamesData = await mixedGameApi.getGames();
        setGames(Array.isArray(gamesData) ? gamesData : (gamesData?.data || []));
        
      } catch (error) {
        console.error('Error in Dashboard:', error);
        // If there's an auth error, redirect to login
        if (error.response && error.response.status === 401) {
          console.log('Auth error, redirecting to login');
          localStorage.removeItem('access_token');
          localStorage.removeItem('token_type');
          navigate('/login');
        }
      } finally {
        setLoading(false);
      }
    };

    checkAuthAndFetchGames();
  }, [navigate]);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress />
      </Box>
    );
  }
  
  // If we have a gameId and results are loading
  if (gameId && loadingResult) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress />
        <Typography variant="body1" ml={2}>Loading game results...</Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" gutterBottom>
          Demand Planning System
        </Typography>
        <Button 
          variant="contained" 
          color="primary"
          onClick={() => navigate('/games/new')}
          startIcon={<AddIcon />}
        >
          New Game
        </Button>
      </Box>

      {gameId && gameResult && (
        <Box mb={4}>
          <Typography variant="h5" gutterBottom>
            Results for Game #{gameId}
          </Typography>
          {/* Add your game result visualization components here */}
          <Paper elevation={2} sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>Game Summary</Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} md={4}>
                <KPIStat 
                  title="Total Score" 
                  value={gameResult.totalScore || 'N/A'} 
                  subtitle="points" 
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <KPIStat 
                  title="Rounds Completed" 
                  value={gameResult.roundsCompleted || '0'} 
                  subtitle="rounds" 
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <KPIStat 
                  title="Status" 
                  value={gameResult.status || 'N/A'} 
                  subtitle={gameResult.status === 'COMPLETED' ? 'Game Over' : 'In Progress'} 
                />
              </Grid>
            </Grid>
          </Paper>
        </Box>
      )}
      
      {!gameId && <FilterBar />}

      {/* KPI cards */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12} md={3}>
          <KPIStat title="Total Demand Forecast" value="248,500" subtitle="units" delta="+1.2% from last period" deltaPositive />
        </Grid>
        <Grid item xs={12} md={3}>
          <KPIStat title="Current Inventory" value="186,240" subtitle="units" delta="-3.5% from last period" />
        </Grid>
        <Grid item xs={12} md={3}>
          <KPIStat title="Forecast Accuracy" value="87.4%" subtitle="+2.7% from last period" delta="+2.7%" deltaPositive />
        </Grid>
        <Grid item xs={12} md={3}>
          <KPIStat title="Stockout Risk" value="3" subtitle="SKUs at risk" />
        </Grid>
      </Grid>

      {/* Demand Forecast Overview */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12}>
          <ChartCard title="Demand Forecast Overview" subtitle="Historical actuals vs forecasted demand for the next 12 weeks">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={demandSeries}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="actual" stroke="#1e88e5" name="Actual Demand" />
                <Line type="monotone" dataKey="forecast" stroke="#e53935" name="Forecasted Demand" strokeDasharray="4 2" />
                <Line type="monotone" dataKey="target" stroke="#43a047" name="Target Demand" />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>
      </Grid>

      {/* Bar charts row */}
      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12} md={6}>
          <ChartCard title="Current Inventory vs Safety Stock" subtitle="Monitor stock levels against safety thresholds" height={300}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stockVsSafety}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" interval={0} angle={-20} textAnchor="end" height={60} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="stock" fill="#1e88e5" name="Current Stock" />
                <Bar dataKey="safety" fill="#e53935" name="Safety Stock" />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>
        <Grid item xs={12} md={6}>
          <ChartCard title="Stock vs Forecast Demand" subtitle="Compare current inventory with projected demand" height={300}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stockVsForecast}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" interval={0} angle={-20} textAnchor="end" height={60} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="stock" fill="#1e88e5" name="Current Stock" />
                <Bar dataKey="forecast" fill="#43a047" name="Forecast Demand" />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>
      </Grid>

      {/* SKU Overview Table */}
      <Typography variant="h6" gutterBottom>SKU Overview</Typography>
      <SkuTable />
    </Box>
  );
};

export default Dashboard;
