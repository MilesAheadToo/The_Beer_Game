import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { 
  FaEye, 
  FaEyeSlash, 
  FaSignInAlt, 
  FaSpinner, 
  FaLock, 
  FaEnvelope,
  FaExclamationCircle 
} from 'react-icons/fa';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { mixedGameApi } from '../services/api';
import './Login.css';

const daybreakLogo = '/daybreak_logo.png';

function Login() {
  const [email, setEmail] = useState('admin@daybreak.ai');
  const [password, setPassword] = useState('Daybreak@2025');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const { isAuthenticated, login: setAuthed } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const hasNavigated = useRef(false);

  // if already authed, bounce to redirect or /games ONCE
  useEffect(() => {
    if (hasNavigated.current) return;
    if (isAuthenticated) {
      hasNavigated.current = true;
      const search = new URLSearchParams(location.search);
      const redirectTo = search.get("redirect") || "/games";
      console.log('Redirecting to:', redirectTo);
      navigate(redirectTo, { replace: true });
    }
  }, [isAuthenticated, location.search, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    
    try {
      // Call the login API directly
      const response = await mixedGameApi.login({ 
        username: email, 
        password,
        grant_type: 'password' 
      });
      
      // Update auth state with token data
      setAuthed({
        access_token: response.access_token,
        token_type: response.token_type
      });
      
    } catch (error) {
      console.error('Login error:', error);
      setError('Invalid email or password');
    } finally {
      setSubmitting(false);
    }
  };
  
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="login-container">
      <motion.div 
        className="login-card"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <header className="login-header">
          <img src={daybreakLogo} alt="Daybreak Logo" className="login-logo" />
          <h1 className="login-title">Welcome Back</h1>
          <p className="login-subtitle">Sign in to continue to Daybreak Beer Game</p>
        </header>

        <form onSubmit={handleSubmit} className="login-form" autoComplete="on">
          <AnimatePresence>
            {error && (
              <motion.div 
                className="error-message"
                initial={{ opacity: 0, height: 0, marginBottom: 0 }}
                animate={{ opacity: 1, height: 'auto', marginBottom: '1rem' }}
                exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                transition={{ duration: 0.2 }}
                role="alert"
                aria-live="assertive"
              >
                <FaExclamationCircle className="error-icon" />
                <span>{error}</span>
              </motion.div>
            )}
          </AnimatePresence>
          
          <div className="form-group">
            <label htmlFor="email" className="form-label">
              <FaEnvelope className="input-icon" /> Email Address
            </label>
            <div className="input-wrapper">
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value.trim())}
                placeholder="Enter your email"
                autoComplete="username"
                disabled={submitting}
                className={`form-input ${error ? 'error' : ''}`}
                autoFocus
                aria-required="true"
                aria-invalid={!!error}
                aria-describedby={error ? 'email-error' : undefined}
              />
            </div>
          </div>
          
          <div className="form-group">
            <div className="form-label-wrapper">
              <label htmlFor="password" className="form-label">
                <FaLock className="input-icon" /> Password
              </label>
              <Link to="/forgot-password" className="forgot-password">
                Forgot Password?
              </Link>
            </div>
            <div className="input-wrapper">
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                autoComplete="current-password"
                disabled={submitting}
                className={`form-input ${error ? 'error' : ''}`}
                aria-required="true"
                aria-invalid={!!error}
                aria-describedby={error ? 'password-error' : undefined}
              />
              <button
                type="button"
                className={`toggle-password ${submitting ? 'disabled' : ''}`}
                onClick={togglePasswordVisibility}
                disabled={submitting}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </button>
            </div>
          </div>
          
          <button 
            type="submit" 
            className="login-button"
            disabled={submitting}
          >
            {submitting ? (
              <>
                <FaSpinner className="spin" /> Logging in...
              </>
            ) : (
              <>
                <FaSignInAlt /> Login
              </>
            )}
          </button>
          
          <div className="login-footer">
            <p>
              Don't have an account?{' '}
              <Link 
                to="/register" 
                className="register-link"
                tabIndex={submitting ? -1 : 0}
                aria-disabled={submitting}
              >
                Sign up
              </Link>
            </p>
          </div>
        </form>
      </motion.div>
      
      <footer className="login-page-footer">
        <p>&copy; {new Date().getFullYear()} Daybreak AI. All rights reserved.</p>
        <div className="footer-links">
          <a href="/privacy">Privacy Policy</a>
          <span className="divider">•</span>
          <a href="/terms">Terms of Service</a>
          <span className="divider">•</span>
          <a href="/contact">Contact Support</a>
        </div>
      </footer>
    </div>
  );
}

export default Login;
