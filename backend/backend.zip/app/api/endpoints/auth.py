from fastapi import APIRouter, Depends, HTTPException, status, Request, Response
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
from sqlalchemy.orm import Session
from typing import Any, List, Optional, Dict
from datetime import datetime, timedelta

from app.core.config import settings
from app.core.deps import get_db, get_current_active_user
from app.core.security import (
    create_access_token, 
    create_refresh_token,
    create_auth_response,
    get_password_hash,
    verify_password
)

# Helper functions for clearing auth cookies
def clear_auth_cookies(response: Response):
    """Clear all authentication related cookies."""
    # Clear access token
    response.delete_cookie(
        key=settings.ACCESS_TOKEN_COOKIE_NAME,
        path="/",
        domain=settings.COOKIE_DOMAIN
    )
    
    # Clear refresh token
    response.delete_cookie(
        key=settings.REFRESH_TOKEN_COOKIE_NAME,
        path=f"{settings.API_V1_STR}/auth/refresh",
        domain=settings.COOKIE_DOMAIN
    )
    
    # Clear CSRF token
    response.delete_cookie(
        key=settings.CSRF_COOKIE_NAME,
        path=settings.CSRF_COOKIE_PATH,
        domain=settings.CSRF_COOKIE_DOMAIN
    )
from app.schemas.user import (
    UserCreate, User, Token, UserUpdate, UserPasswordChange,
    MFASetupResponse, MFAVerifyRequest, MFARecoveryCodes
)
from app.services.auth_service import AuthService
from app.models.user import User as UserModel

router = APIRouter()

def get_auth_service(db: Session = Depends(get_db)) -> AuthService:
    """Dependency to get an instance of AuthService."""
    return AuthService(db)

@router.post("/register", response_model=User, status_code=status.HTTP_201_CREATED)
async def register(
    user_in: UserCreate,
    response: Response,
    db: Session = Depends(get_db)
) -> Any:
    """
    Register a new user.
    
    - **email**: Must be a valid email address
    - **password**: Must be at least 8 characters, with at least one uppercase, one lowercase, and one number
    - **full_name**: User's full name
    """
    # Check if user with this email already exists
    db_user = db.query(UserModel).filter(UserModel.email == user_in.email).first()
    if db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Create new user
    hashed_password = get_password_hash(user_in.password)
    db_user = UserModel(
        email=user_in.email,
        hashed_password=hashed_password,
        full_name=user_in.full_name,
        is_active=True,
        is_superuser=False
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    # Log the user in after registration
    return create_auth_response(str(db_user.id), response)

@router.post("/login", response_model=Token)
async def login(
    request: Request,
    response: Response,
    form_data: OAuth2PasswordRequestForm = Depends(),
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    OAuth2 compatible token login, get an access token for future requests.
    
    - **username**: Your username or email
    - **password**: Your password
    - **mfa_code**: MFA code if MFA is enabled (optional)
    - **device_info**: Device information for audit logging (optional)
    
    Returns an access token in the response body and sets an HTTP-only refresh token cookie.
    """
    try:
        # Get client IP and user agent for audit logging
        client_ip = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent")
        
        # Call the auth service to authenticate the user
        tokens = await auth_service.authenticate_user(
            username=form_data.username,
            password=form_data.password,
            mfa_code=form_data.mfa_code if hasattr(form_data, 'mfa_code') else None,
            client_ip=client_ip,
            user_agent=user_agent
        )
        
        if not tokens:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Set the refresh token in an HTTP-only cookie
        set_refresh_cookie(
            response=response,
            refresh_token=tokens.refresh_token,
            expires_days=settings.REFRESH_TOKEN_EXPIRE_DAYS
        )
        
        # Return only the access token in the response body
        return {
            "access_token": tokens.access_token,
            "token_type": tokens.token_type
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error during login: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred during login: {str(e)}"
        )

@router.post("/mfa/setup", response_model=MFASetupResponse)
def setup_mfa(
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    Set up Multi-Factor Authentication for the current user.
    
    Generates a new MFA secret and returns it along with a provisioning URI
    that can be used with authenticator apps like Google Authenticator.
    
    Requires authentication.
    """
    if current_user.mfa_enabled:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is already enabled for this account"
        )
        
    # Generate a new MFA secret
    secret = auth_service.generate_mfa_secret(current_user)
    
    # Generate a provisioning URI for the authenticator app
    uri = auth_service.generate_mfa_uri(current_user, secret)
    
    # Generate recovery codes
    recovery_codes = auth_service.generate_recovery_codes(current_user)
    
    return {
        "secret": secret,
        "uri": uri,
        "recovery_codes": recovery_codes
    }

@router.post("/mfa/verify", response_model=Token)
def verify_mfa(
    mfa_verify: MFAVerifyRequest,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    Verify an MFA code and complete MFA setup.
    
    - **code**: The MFA code from the authenticator app
    
    Returns a new access token and refresh token if verification is successful.
    
    Requires authentication and an unverified MFA setup.
    """
    if current_user.mfa_enabled:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is already enabled for this account"
        )
        
    if not current_user.mfa_secret:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is not set up for this account"
        )
    
    # Verify the MFA code
    if not auth_service.enable_mfa(current_user, mfa_verify.code):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid MFA code"
        )
    
    # Generate new tokens with MFA verified
    return auth_service.create_access_token(current_user, mfa_verified=True)

@router.post("/mfa/disable", status_code=status.HTTP_204_NO_CONTENT)
def disable_mfa(
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
) -> None:
    """
    Disable MFA for the current user.
    
    Requires authentication and MFA to be enabled.
    """
    if not current_user.mfa_enabled:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is not enabled for this account"
        )
    
    auth_service.disable_mfa(current_user)

@router.post("/mfa/recovery-codes", response_model=MFARecoveryCodes)
def generate_recovery_codes(
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    Generate new MFA recovery codes.
    
    This will invalidate any previously generated recovery codes.
    
    Requires authentication and MFA to be enabled.
    """
    if not current_user.mfa_enabled:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MFA is not enabled for this account"
        )
    
    recovery_codes = auth_service.generate_recovery_codes(current_user)
    return {"recovery_codes": recovery_codes}

@router.post("/mfa/verify-recovery", response_model=Token)
def verify_recovery_code(
    mfa_verify: MFAVerifyRequest,
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    Verify a recovery code and get a new access token.
    
    - **code**: The recovery code to verify
    
    Returns a new access token and refresh token if the recovery code is valid.
    """
    # Get user from the recovery code
    user = auth_service.verify_recovery_code(mfa_verify.code)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired recovery code"
        )
    
    # Generate new tokens with MFA verified
    return auth_service.create_access_token(user, mfa_verified=True)

@router.post("/refresh", response_model=Dict[str, Any])
async def refresh_token(
    request: Request,
    response: Response,
    db: Session = Depends(get_db)
):
    """
    Refresh the access token using the refresh token from cookie.
    
    Returns a new access token and updates the refresh token in the HTTP-only cookie.
    """
    refresh_token = request.cookies.get(settings.REFRESH_TOKEN_COOKIE_NAME)
    if not refresh_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token is missing",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    try:
        # Verify refresh token
        payload = jwt.decode(
            refresh_token,
            settings.REFRESH_SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        
        # Check token type
        token_type = payload.get("type")
        if token_type != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token type",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Get user ID from token
        user_id = payload.get("sub")
        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Check if user exists and is active
        user = db.query(UserModel).filter(UserModel.id == int(user_id)).first()
        if not user or not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found or inactive",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        # Create new auth response with cookies
        return create_auth_response(str(user.id), response)
        
    except JWTError as e:
        # Clear invalid refresh token
        clear_auth_cookies(response)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
            headers={"WWW-Authenticate": "Bearer"},
        )

@router.get("/me", response_model=User)
def read_users_me(
    current_user: User = Depends(get_current_active_user)
) -> Any:
    """
    Get current user information.
    
    Requires authentication.
    """
    return {
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "is_active": current_user.is_active,
        "is_superuser": current_user.is_superuser,
        "created_at": current_user.created_at,
        "updated_at": current_user.updated_at
    }

@router.put("/me", response_model=User)
def update_user_me(
    user_in: UserUpdate,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    Update current user information.
    
    - **email**: New email (optional)
    - **full_name**: New full name (optional)
    - **is_active**: Whether the user is active (admin only)
    
    Requires authentication.
    """
    return auth_service.update_user(current_user.id, user_in)

@router.post("/change-password", response_model=User)
def change_password(
    password_change: UserPasswordChange,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    Change the current user's password.
    
    - **current_password**: Current password
    - **new_password**: New password (must be at least 8 characters, with at least one uppercase, one lowercase, and one number)
    
    Requires authentication.
    """
    try:
        return auth_service.change_password(
            current_user.id,
            password_change.current_password,
            password_change.new_password
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

@router.post("/logout")
async def logout(
    response: Response,
    current_user: User = Depends(get_current_active_user)
):
    """
    Log out the current user by clearing authentication cookies.
    
    Requires authentication.
    """
    clear_auth_cookies(response)
    return {"detail": "Successfully logged out"}

# Admin-only endpoints
@router.get("/users/", response_model=list[User])
def read_users(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    Retrieve all users (admin only).
    
    - **skip**: Number of users to skip (for pagination)
    - **limit**: Maximum number of users to return (for pagination)
    
    Requires admin privileges.
    """
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    return auth_service.get_users(skip=skip, limit=limit)

@router.get("/users/{user_id}", response_model=User)
def read_user(
    user_id: int,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    Get a specific user by ID (admin only).
    
    - **user_id**: ID of the user to retrieve
    
    Requires admin privileges.
    """
    if not current_user.is_superuser and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    user = auth_service.get_user(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    return user
