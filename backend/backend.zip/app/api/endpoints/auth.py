from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import (
    create_access_token,
    get_password_hash,
    verify_password,
    set_auth_cookies,
    clear_auth_cookies,
    get_current_user,
    get_current_active_user,
)
from app.db.session import get_db
from app.models.user import User, UserCreate, UserInDB, UserPublic, UserUpdate, UserBase, UserPasswordChange
from app.repositories.users import (
    create_user as create_user_repo,
    get_user_by_email,
    update_user as update_user_repo,
)
from app.services.auth_service import AuthService, get_auth_service
from app.schemas.mfa import MFAVerifyRequest

router = APIRouter()

class TokenResponse(BaseModel):
    """Response model for authentication tokens."""
    access_token: str
    token_type: str = "bearer"
    user: UserPublic

# Alias Token to TokenResponse for backward compatibility
Token = TokenResponse

class LoginRequest(BaseModel):
    """Request model for login endpoint."""
    email: EmailStr
    password: str = Field(..., min_length=8)

class RegisterRequest(UserCreate):
    """Request model for registration endpoint."""
    pass

@router.post("/login", response_model=Token)
async def login(
    request: Request,
    response: Response,
    form_data: OAuth2PasswordRequestForm = Depends(),
    auth_service: AuthService = Depends(get_auth_service)
) -> Any:
    """
    OAuth2 compatible token login, get an access token for future requests.
    
    - **username**: Your email
    - **password**: Your password
    - **mfa_code**: MFA code if MFA is enabled (optional)
    - **device_info**: Device information for audit logging (optional)
    
    Returns an access token in the response body and sets an HTTP-only refresh token cookie.
    """
    # Authenticate user
    user = await auth_service.authenticate_user(
        email=form_data.username,  # username is actually email
        password=form_data.password,
        mfa_code=form_data.client_secret if hasattr(form_data, 'client_secret') else None,
        device_info=request.headers.get('User-Agent')
    )
    
    # Generate tokens
    tokens = await auth_service.create_tokens(user)
    
    # Set HTTP-only cookies
    response.set_cookie(
        key="refresh_token",
        value=tokens.refresh_token,
        httponly=True,
        secure=not settings.DEBUG,
        samesite="lax",
        max_age=settings.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60
    )
    
    # Return access token and user info
    return TokenResponse(
        access_token=tokens.access_token,
        token_type="bearer",
        user=UserPublic.from_orm(user)
    )

@router.post("/register", response_model=UserPublic, status_code=status.HTTP_201_CREATED)
async def register(
    user_in: UserCreate,
    response: Response,
    db: Session = Depends(get_db)
) -> Any:
    """
    Register a new user.
    
    - **email**: Must be a valid email address
    - **password**: Must be at least 8 characters, with at least one uppercase, one lowercase, and one number
    - **full_name**: User's full name
    """
    # Check if user with this email already exists
    db_user = await get_user_by_email(db, user_in.email)
    if db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Create new user
    hashed_password = get_password_hash(user_in.password)
    db_user = User(
        email=user_in.email,
        hashed_password=hashed_password,
        full_name=user_in.full_name,
        is_active=True,
        is_superuser=False
    )
    
    db.add(db_user)
    await db.commit()
    await db.refresh(db_user)
    
    return db_user

@router.post("/logout")
async def logout(
    response: Response,
    current_user: User = Depends(get_current_active_user)
):
    """
    Log out the current user by clearing authentication cookies.
    
    Requires authentication.
    """
    clear_auth_cookies(response)
    return {"message": "Successfully logged out"}

@router.get("/me", response_model=UserPublic)
async def read_users_me(
    current_user: User = Depends(get_current_active_user)
):
    """
    Get current user information.
    
    Requires authentication.
    """
    return current_user

@router.put("/me", response_model=UserPublic)
async def update_user_me(
    user_in: UserUpdate,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Update current user information.
    
    - **email**: New email (optional)
    - **full_name**: New full name (optional)
    - **is_active**: Whether the user is active (admin only)
    
    Requires authentication.
    """
    return await auth_service.update_user(current_user.id, user_in)

@router.post("/change-password")
async def change_password(
    password_change: UserPasswordChange,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Change the current user's password.
    
    - **current_password**: Current password
    - **new_password**: New password (must be at least 8 characters, with at least one uppercase, one lowercase, and one number)
    
    Requires authentication.
    """
    await auth_service.change_password(
        user=current_user,
        current_password=password_change.current_password,
        new_password=password_change.new_password
    )
    return {"message": "Password updated successfully"}

# MFA Endpoints
@router.post("/mfa/setup")
async def setup_mfa(
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Set up Multi-Factor Authentication for the current user.
    
    Generates a new MFA secret and returns it along with a provisioning URI
    that can be used with authenticator apps like Google Authenticator.
    
    Requires authentication.
    """
    return await auth_service.setup_mfa(current_user)

@router.post("/mfa/verify")
async def verify_mfa(
    mfa_verify: MFAVerifyRequest,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Verify an MFA code and complete MFA setup.
    
    - **code**: The MFA code from the authenticator app
    
    Returns a new access token and refresh token if verification is successful.
    
    Requires authentication and an unverified MFA setup.
    """
    return await auth_service.verify_mfa(current_user, mfa_verify.code)

@router.post("/mfa/disable")
async def disable_mfa(
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Disable MFA for the current user.
    
    Requires authentication and MFA to be enabled.
    """
    await auth_service.disable_mfa(current_user)
    return {"message": "MFA disabled successfully"}

@router.post("/mfa/recovery-codes")
async def generate_recovery_codes(
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Generate new MFA recovery codes.
    
    This will invalidate any previously generated recovery codes.
    
    Requires authentication and MFA to be enabled.
    """
    return await auth_service.generate_recovery_codes(current_user)

@router.post("/mfa/recover")
async def verify_recovery_code(
    mfa_verify: MFAVerifyRequest,
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Verify a recovery code and get a new access token.
    
    - **code**: The recovery code to verify
    
    Returns a new access token and refresh token if the recovery code is valid.
    """
    return await auth_service.verify_recovery_code(mfa_verify.code)

@router.post("/refresh-token")
async def refresh_token(
    request: Request,
    response: Response,
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Refresh the access token using the refresh token from cookie.
    
    Returns a new access token and updates the refresh token in the HTTP-only cookie.
    """
    refresh_token = request.cookies.get("refresh_token")
    if not refresh_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not refresh access token"
        )
    
    tokens = await auth_service.refresh_tokens(refresh_token)
    
    # Set the new refresh token in HTTP-only cookie
    response.set_cookie(
        key="refresh_token",
        value=tokens.refresh_token,
        httponly=True,
        secure=not settings.DEBUG,
        samesite="lax",
        max_age=settings.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60
    )
    
    return {"access_token": tokens.access_token, "token_type": "bearer"}

# Admin-only endpoints
@router.get("/users/", response_model=List[UserPublic])
async def read_users(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Retrieve all users (admin only).
    
    - **skip**: Number of users to skip (for pagination)
    - **limit**: Maximum number of users to return (for pagination)
    
    Requires admin privileges.
    """
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    return await auth_service.get_users(skip=skip, limit=limit)

@router.get("/users/{user_id}", response_model=UserPublic)
async def read_user(
    user_id: int,
    current_user: User = Depends(get_current_active_user),
    auth_service: AuthService = Depends(get_auth_service)
):
    """
    Get a specific user by ID (admin only).
    
    - **user_id**: ID of the user to retrieve
    
    Requires admin privileges.
    """
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    return await auth_service.get_user(user_id)
